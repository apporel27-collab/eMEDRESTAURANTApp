Place a restaurant/bar themed background image named `login-bg-restaurant.jpg` in this folder. Recommended size: 1920x1080, optimized for web (JPEG/WEBP). You can use a royalty-free image from Unsplash or Pexels (search for "restaurant bar interior", "restaurant background", "bar ambience").

This file exists so the repository includes the images folder; add the actual image file before deploying the site to production.
